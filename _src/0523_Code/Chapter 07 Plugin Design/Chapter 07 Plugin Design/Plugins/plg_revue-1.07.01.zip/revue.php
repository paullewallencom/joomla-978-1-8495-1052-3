<?php
/**
 * Boxoffice Revue Plugin 
 * 
 * @package    	plg_revue
 * @subpackage 	plugins
 * @link 				http://www.packtpub.com
 * @license			GNU/GPL
 */
	
	// No direct access 
	defined( '_JEXEC' ) or die( 'Restricted access' );
	
	// Import the JPlugin class
	jimport('joomla.event.plugin');
	
	/**
	 *  Box Office event listener event
	 *
	 */
	class plgBoxofficeRevue extends JPlugin
	{
		/**
		 *  Handle onPrepareRevue
		 *
		 */
		function onPrepareRevue(&$revue)  
		{
			// look for images in template if available  
			$starImageOn  = '<img src="plugins/boxoffice/star_on.png" />';
			$starImageOff = '<img src="plugins/boxoffice/star_off.png" />';
			
			$img='';
			
			for ($i=0; $i < strlen($revue->stars); $i++) 
			{
				$img .= $starImageOn;
			}
			
			for ($i=strlen($revue->stars); $i < 5; $i++) 
			{
				$img .= $starImageOff;
			}
			
			$revue->stars = $img;
		}
	}