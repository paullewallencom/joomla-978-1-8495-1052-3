<?php
/**
 * Boxoffice Install Script
 * 
 * @package    	com_boxoffice
 * @subpackage 	components
 * @link 				http://www.packtpub.com
 * @license			GNU/GPL
 */

	function com_install()
	{
		// Execute some code here
		// <code>
		
		echo "<p>Thank you for installing Boxoffice.</p>";
		
		return true;
	}
?>