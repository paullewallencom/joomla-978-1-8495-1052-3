<?php
/**
 * Boxoffice Uninstall Script
 * 
 * @package    	com_boxoffice
 * @subpackage 	components
 * @link 				http://www.packtpub.com
 * @license			GNU/GPL
 */

	function com_uninstall()
	{
		// Execute some code here
		// <code>
		
		echo "<p>We are sorry that you found it necessary to uninstall Boxoffice.</p>";
		
		return true;
	}
?>