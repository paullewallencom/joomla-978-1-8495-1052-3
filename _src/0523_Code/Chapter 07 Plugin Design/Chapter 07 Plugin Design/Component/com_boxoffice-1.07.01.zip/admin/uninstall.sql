drop table if exists #__boxoffice_revues;
drop table if exists #__boxoffice_comments;